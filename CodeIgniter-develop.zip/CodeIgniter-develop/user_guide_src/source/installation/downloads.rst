#######################
Downloading CodeIgniter
#######################

-  `CodeIgniter v3.0.0 (Current version) <http://ellislab.com/codeigniter/download>`_
-  `CodeIgniter v2.2.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.2.0.zip>`_ (MD5 Checksum: dbfddde4ec0b12027aee5156fbdd634b)
-  `CodeIgniter v2.1.4 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.1.4.zip>`_ (MD5 Checksum: e74a296c1d412a855c025b9cd468a513)
-  `CodeIgniter v2.1.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.1.3.zip>`_ (MD5 Checksum: 781d06be06eaa36f10759ef82c8594d5)
-  `CodeIgniter v2.1.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.1.2.zip>`_ (MD5 Checksum: c7a2980dff2774c97bd38bfbf450d8d5)
-  `CodeIgniter v2.1.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.1.1.zip>`_ (MD5 Checksum: c4aa5f188f4ff16f919607b46a16c76c)
-  `CodeIgniter v2.1.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.1.0.zip>`_ (MD5 Checksum: 8cb676b0f831114935d7dd1ae2e0d490)
-  `CodeIgniter v2.0.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.0.3.zip>`_ (MD5 Checksum: 910475d50daf088bdd949c3d35b444d9)
-  `CodeIgniter v2.0.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.0.2.zip>`_ (MD5 Checksum: e75bab8cf27d2fb2483c5bb61b85a524)
-  `CodeIgniter v2.0.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.0.1.zip>`_ (MD5 Checksum: 675aa95896bfb16467436c0484f15f1f)
-  `CodeIgniter v2.0.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_2.0.0.zip>`_ (MD5 Checksum: bd657863de45dbb397f3b3dbc4f13abb)
-  `CodeIgniter v1.7.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.7.3.zip>`_ (MD5 Checksum: 16f50e7df4f44c1defe18355131049e9)
-  `CodeIgniter v1.7.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.7.2.zip>`_ (MD5 Checksum: ff2f4d1b3ab921f91e006f38b3ae6540)
-  `CodeIgniter v1.7.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.7.1.zip>`_ (MD5 Checksum: deca9709cf21b26dc0e4ec040b37e866)
-  `CodeIgniter v1.7.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.7.0.zip>`_ (MD5 Checksum: 28037f2071f940d8756864460d949045)
-  `CodeIgniter v1.6.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.6.3.zip>`_ (MD5 Checksum: 5ffab52b39b235ed6bd08ee5dd64d2f6)
-  `CodeIgniter v1.6.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.6.2.zip>`_ (MD5 Checksum: 0922830f96dfd40874b39ad018a49206)
-  `CodeIgniter v1.6.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.6.1.zip>`_ (MD5 Checksum: cc3f0b566e3654d351fa067aeee9bced)
-  `CodeIgniter v1.6.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.6.0.zip>`_ (MD5 Checksum: 89efabb8c1d57bb51071e6a20bb5590d)
-  `CodeIgniter v1.5.4 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.5.4.zip>`_ (MD5 Checksum: 0d6cc66b01d5ddecde483b3d5f51e4f8)
-  `CodeIgniter v1.5.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.5.3.zip>`_ (MD5 Checksum: f44dd21d34a2842bd052879ca5de6630)
-  `CodeIgniter v1.5.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.5.2.zip>`_ (MD5 Checksum: 78e7106b271f75af48e626f6e923c1aa)
-  `CodeIgniter v1.5.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.5.1.zip>`_ (MD5 Checksum: 9dfd0dbed4f283a42a817e1e88f97481)
-  `CodeIgniter v1.5.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.5.0.zip>`_ (MD5 Checksum: 116b805eae4b7e78ddd43a8aee733632)
-  `CodeIgniter v1.4.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.4.1.zip>`_ (MD5 Checksum: 470005a83772e9d2e99dec2b4058e584)
-  `CodeIgniter v1.4.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.4.0.zip>`_ (MD5 Checksum: 43ca6ff3447d6b5681f98a328b386338)
-  `CodeIgniter v1.3.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.3.3.zip>`_ (MD5 Checksum: 55692ba4b55b53b58e4514e310288981)
-  `CodeIgniter v1.3.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.3.2.zip>`_ (MD5 Checksum: 7dace6e1d6245b569943e8df952c7637)
-  `CodeIgniter v1.3.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.3.1.zip>`_ (MD5 Checksum: f6c6f00830c60d7f98b948269ee81069)
-  `CodeIgniter v1.3 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.3.zip>`_ (MD5 Checksum: 03b2f796df6af808ecff3a18b6000477)
-  `CodeIgniter v1.2 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.2.zip>`_ (MD5 Checksum: f9289814fabe102bc35beb791d0c0f62)
-  `CodeIgniter v1.1 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.1b.zip>`_ (MD5 Checksum: bf4cabb6a3ea3122a974270b8044befb)
-  `CodeIgniter v1.0 <http://ellislab.com/asset/ci_download_files/CodeIgniter_1.0b.zip>`_ (MD5 Checksum: 427ca4255e2bdaacee976de1aa143ea0)


******
GitHub
******

`Git <http://git-scm.com/about>`_ is a distributed version control system.

Public Git access is available at `GitHub <https://github.com/bcit-ci/CodeIgniter>`_.
Please note that while every effort is made to keep this code base
functional, we cannot guarantee the functionality of code taken from
the develop branch.

Beginning with version 2.0.3, stable versions are also available via `GitHub Releases <https://github.com/bcit-ci/CodeIgniter/releases>`_.